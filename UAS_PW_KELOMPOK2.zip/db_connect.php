<?php
	$db = new PDO("mysql:host=localhost;dbname=relawan", "root", "");
	return $db;
?>